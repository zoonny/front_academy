export const NEWS_URL = 'https://api.hnpwa.com/v0/news/1.json';
export const CONTENT_URL = 'https://api.hnpwa.com/v0/item/@id.json';
