export { default as NewsDetailView }  from './news-detail-view';
export { default as NewsFeedView }  from './news-feed-view';
