export const nextTick = (fn: Function) => setTimeout(fn, 16);
