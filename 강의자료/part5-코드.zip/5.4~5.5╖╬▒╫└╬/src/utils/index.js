export const nextTick = fn => setTimeout(fn, 16);
